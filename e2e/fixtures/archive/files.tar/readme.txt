This archive is an e2e fixture for tools.dcln.me.
